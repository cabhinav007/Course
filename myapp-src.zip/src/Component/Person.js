import React from 'react'

const person = (pro) => {
  return (
    <div>
        <h1>{pro.name},{pro.age} </h1>
    </div>
  )
}

export default person