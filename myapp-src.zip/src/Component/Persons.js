import React from 'react'

const Persons = (pro) => {
  return (
    <div>
        <h1>{pro.name} {pro.age} </h1>
    </div>
  )
}

export default Persons