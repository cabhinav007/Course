import React from 'react'

const Services = () => {
  return (
    <div>
      <h1>service</h1>
    </div>
  )
}

export default Services
