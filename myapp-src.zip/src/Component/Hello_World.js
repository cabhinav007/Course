import React from 'react'

const Hello_World = () => {
  return (
    <div><h1>Hello_World</h1></div>
  )
}

export default Hello_World